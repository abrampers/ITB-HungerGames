% File move.pl
/*
	Abram Perdanaputra 		(13516083)
	Faza Fahleraz 			(13516095)
	Dandy Arif Rahman 		(13516086)
	Dzaky El Fikri 			(18214XXX)
	Yusuf Rahmat Pratama 	(13516062)
*/

% Move commands
% Sistem koordinat sama kaya alstrukdat 0,0 di pojok kanan atas dengan X adalah Kolom dan Y adalah Baris

is_move_valid(X, Y) :- 
	mapAt(X, Y, Type),
	Type \== '#',
	!.

n :- 
	playerLocation(X, Y),
	NewX is X - 1,
	is_move_valid(NewX, Y),
	isThirsty(T),
	retract(playerLocation(X, Y)), 
	asserta(playerLocation(NewX, Y)),
	hunger(H),
	retract(hunger(H)),
	NewH is H - 1,
	asserta(hunger(NewH)),
	thirst(TempT),
	retract(thirst(TempT)),
	asserta(thirst(T)),
	retract(isThirsty(T)),
	!.

n :- 
	playerLocation(X, Y),
	NewX is X - 1,
	is_move_valid(NewX, Y),
	retract(playerLocation(X, Y)), 
	asserta(playerLocation(NewX, Y)),
	hunger(H),
	retract(hunger(H)),
	NewH is H - 1,
	asserta(hunger(NewH)),
	thirst(T),
	NewT is T - 1,
	asserta(isThirsty(NewT)),
	!.

n :- 
	print('Sorry, you cannout move anymore, you are on the northernmost point!'),!.

e :- 
	playerLocation(X, Y),
	NewY is Y + 1,
	is_move_valid(X, NewY),
	isThirsty(T),
	retract(playerLocation(X, Y)), 
	asserta(playerLocation(X, NewY)),
	hunger(H),
	retract(hunger(H)),
	NewH is H - 1,
	asserta(hunger(NewH)),
	thirst(TempT),
	retract(thirst(TempT)),
	asserta(thirst(T)),
	retract(isThirsty(T)),
	!.

e :- 
	playerLocation(X, Y),
	NewY is Y + 1,
	is_move_valid(X, NewY),
	retract(playerLocation(X, Y)), 
	asserta(playerLocation(X, NewY)),
	hunger(H),
	retract(hunger(H)),
	NewH is H - 1,
	asserta(hunger(NewH)),
	thirst(T),
	NewT is T - 1,
	asserta(isThirsty(NewT)),
	!.

e :- 
	print('Sorry, you cannout move anymore, you are on the easternmost point!'),!.

w :- 
	playerLocation(X, Y),
	NewY is Y - 1,
	is_move_valid(X, NewY),
	isThirsty(T),
	retract(playerLocation(X, Y)), 
	asserta(playerLocation(X, NewY)),
	hunger(H),
	retract(hunger(H)),
	NewH is H - 1,
	asserta(hunger(NewH)),
	thirst(TempT),
	retract(thirst(TempT)),
	asserta(thirst(T)),
	retract(isThirsty(T)),
	!.

w :- 
	playerLocation(X, Y),
	NewY is Y - 1,
	is_move_valid(X, NewY),
	retract(playerLocation(X, Y)), 
	asserta(playerLocation(X, NewY)),
	hunger(H),
	retract(hunger(H)),
	NewH is H - 1,
	asserta(hunger(NewH)),
	thirst(T),
	NewT is T - 1,
	asserta(isThirsty(NewT)),
	!.

w :- 
	print('Sorry, you cannot move anymore, you are on the westernmost point!'),!.

s :- 
	playerLocation(X, Y),
	NewX is X + 1,
	is_move_valid(NewX, Y),
	isThirsty(T),
	retract(playerLocation(X, Y)), 
	asserta(playerLocation(NewX, Y)),
	hunger(H),
	retract(hunger(H)),
	NewH is H - 1,
	asserta(hunger(NewH)),
	thirst(TempT),
	retract(thirst(TempT)),
	asserta(thirst(T)),
	retract(isThirsty(T)),
	!.

s :- 
	playerLocation(X, Y),
	NewX is X + 1,
	is_move_valid(NewX, Y),
	retract(playerLocation(X, Y)), 
	asserta(playerLocation(NewX, Y)),
	hunger(H),
	retract(hunger(H)),
	NewH is H - 1,
	asserta(hunger(NewH)),
	thirst(T),
	NewT is T - 1,
	asserta(isThirsty(NewT)),
	!.

s :- 
	print('Sorry, you cannout move anymore, you are on the southernmost point!'),!.

